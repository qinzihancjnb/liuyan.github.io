'use client'

import React, { useState, useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { Send } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface Message {
  id: number
  text: string
}

export default function Component() {
  const [messages, setMessages] = useState<Message[]>([])
  const [inputText, setInputText] = useState('')
  const [showAllMessages, setShowAllMessages] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // 模拟从服务器获取消息
    const initialMessages = [
      { id: 1, text: '欢迎来到留言板！' },
      { id: 2, text: '这是一条示例消息' },
      { id: 3, text: '你可以在这里发送消息' },
    ]
    setMessages(initialMessages)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (inputText.trim()) {
      const newMessage = { id: Date.now(), text: inputText.trim() }
      setMessages(prev => [...prev, newMessage])
      setInputText('')
    }
  }

  const handleScroll = () => {
    if (containerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = containerRef.current
      if (scrollTop + clientHeight >= scrollHeight - 10) {
        setShowAllMessages(true)
      } else {
        setShowAllMessages(false)
      }
    }
  }

  return (
    <div className="flex flex-col h-screen bg-gray-100 dark:bg-gray-900">
      {/* 弹幕区域 */}
      <div className="flex-1 overflow-hidden relative">
        {messages.map((message) => (
          <motion.div
            key={message.id}
            className="absolute whitespace-nowrap text-black dark:text-white text-opacity-80 dark:text-opacity-80"
            initial={{ right: "-100%", y: Math.random() * 100 + "%"  }}
            animate={{ right: "100%" }}
            transition={{ duration: 10, repeat: Infinity, repeatType: "loop" }}
          >
            {message.text}
          </motion.div>
        ))}
      </div>

      {/* 消息列表区域 */}
      <div 
        ref={containerRef}
        className="flex-1 overflow-y-auto"
        onScroll={handleScroll}
      >
        <div className="p-4 space-y-4">
          {messages.map((message) => (
            <div key={message.id} className="bg-white dark:bg-gray-800 rounded-lg p-3 shadow">
              {message.text}
            </div>
          ))}
        </div>
      </div>

      {/* 输入区域 */}
      <form onSubmit={handleSubmit} className="p-4 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
        <div className="flex space-x-2">
          <Input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="输入你的留言..."
            className="flex-1"
          />
          <Button type="submit" size="icon">
            <Send className="h-4 w-4" />
            <span className="sr-only">发送</span>
          </Button>
        </div>
      </form>
    </div>
  )
}